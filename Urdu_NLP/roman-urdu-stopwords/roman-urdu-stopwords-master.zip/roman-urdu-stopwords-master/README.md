# Roman Urdu Stopwords List
A list of most frequently used Roman Urdu words with different spellings and usages.

This is a very basic effort to collect some basic stopwords for Roman Urdu to help efforts of analyzing text data in roman Urdu which makes up a huge part of daily internet interaction of Urdu speakers.

The stopwords are mostly compiled using considerably large set of Facebook Messenger chats in Roman Urdu, please feel free to share your opinions or suggest improvements.
