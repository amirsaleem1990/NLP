# UrduDateConverter
Project to convert a gregorian user-input date to the corresponding Urdu calendar date. Note: Urdu, not Arabic.

# Sources
Umm Al Qura Islamic Calendar : https://gist.github.com/fatfingers/6492017
