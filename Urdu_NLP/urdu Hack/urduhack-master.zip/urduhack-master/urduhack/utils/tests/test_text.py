# coding: utf8
"""Test cases for text.py file"""
