# coding: utf8
"""Project Entry point"""
from .about import __version__
from .normalization import normalize

__all__ = ["__version__", "normalize"]
