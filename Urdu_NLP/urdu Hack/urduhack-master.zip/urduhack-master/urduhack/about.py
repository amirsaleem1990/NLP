# coding: utf8
"""Project Meta data description"""

__version__ = '0.1.4'
__description__ = 'Natural Language Processing (NLP) library for Urdu language.'
__url__ = 'https://github.com/urduhack/urduhack'
__author__ = 'Ikram Ali'
__author_email__ = 'mrikram1989@gmail.com'
__license__ = 'MIT License'
