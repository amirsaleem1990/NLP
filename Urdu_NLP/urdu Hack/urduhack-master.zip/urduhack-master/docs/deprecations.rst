.. _deprecations:

Deprecations and removals
=========================

This page lists urduhack features that are deprecated, or have been removed in
past major releases, and gives the alternatives to use instead.
