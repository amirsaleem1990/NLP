Tokenization
-------------

.. automodule:: urduhack.tokenization

.. automodule:: urduhack.tokenization.tokenizer
    :members:
