.. py:module:: urduhack.utils.text
.. py:currentmodule:: urduhack.utils.text


:py:mod:`urduhack.utils.text` Module
=====================================

