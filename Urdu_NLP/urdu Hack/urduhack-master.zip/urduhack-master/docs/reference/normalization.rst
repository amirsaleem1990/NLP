Normalization
-------------

.. automodule:: urduhack.normalization
    :members: normalize

.. automodule:: urduhack.normalization.character
    :members:

.. automodule:: urduhack.normalization.util
    :members: