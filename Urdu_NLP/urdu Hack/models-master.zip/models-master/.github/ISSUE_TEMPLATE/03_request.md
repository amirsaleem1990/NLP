---
name: "\U0001F381 Feature Request"
about: Do you have an idea for an improvement, a new feature?

---

## Feature description
<!-- Please describe the feature: Which area of the library is it related to? What specific solution would you like? -->

