---
name: "\U0001F4AC Anything else?"
about: For general usage questions or help with your code, please consider
  posting on StackOverflow instead.

---

<!-- Describe your issue here. Please keep in mind that the GitHub issue tracker is mostly intended for reports related to the code base and source, and for bugs and feature requests. If you're looking for help with your code, consider posting a question on StackOverflow instead: http://stackoverflow.com/questions/tagged/urduhack -->

## Your Environment
* Operating System:
* Python Version Used:
* Environment Information:
