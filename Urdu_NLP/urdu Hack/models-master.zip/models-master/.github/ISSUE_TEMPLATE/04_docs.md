---
name: "\U0001F4DA Documentation"
about: Did you spot a mistake in the docs, is anything unclear or do you have a
  suggestion?

---
<!-- Describe the problem or suggestion here. If you've found a mistake and you know the answer, feel free to submit a pull request straight away: https://github.com/urduhack/urduhack/pulls -->

## Which page or section is this issue related to?
<!-- Please include the URL and/or source. -->
