In the home directory, you can find 3 folders, with names "docs", "PSGuidelines" and "DSGuidelines".

In the directory "docs", you can find the documents related to SSF format (ssf-guide.pdf), Morph Specification (Morph-specification.pdf), HTB Guidelines (HTB-guidelines-ver2.5.doc), Chunk POS Annotation Guidelines (Chunk-POS-Annotaion-Guidelines.doc), List of POS and Chunk Dependency Relations (List-POS-Chunk-Dependency-Relations.doc). 

In the directories "DSGuidelines" and "PSGuidelines", there will be 5 directories each with the names "DS", "DS-Const", "PB", "PS" and "pdf". 

- In the directory "DS", you can find 2 directories "ssf" and "conll", each having both utf and wx versions. 

- In the directories "DS-Const", "PS" and "PB", there will be 1 directory with name "ssf", containing both utf and wx versions. The files in these directories have an extension ".utf" or ".wx" to indicate the format of data. 

- The directory "pdf" shows all the layers of annotation in a graphical representation. As pdf files are bigger than text files, we divide sentences into several pdf files.  

- At the same level of those directories, there will be a ".xml" file which includes all the layers of annotation in a xml format. 
